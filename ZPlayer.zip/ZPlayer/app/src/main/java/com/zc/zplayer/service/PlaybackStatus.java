package com.zc.zplayer.service;

public enum PlaybackStatus {
    PLAYING,
    PAUSED
}
